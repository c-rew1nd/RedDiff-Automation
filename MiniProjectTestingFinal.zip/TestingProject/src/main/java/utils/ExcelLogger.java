package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExcelLogger {
    private Workbook workbook;
    private Sheet sheet;
    private int rowCount = 0;
    private static final String FILE_NAME = "registration_log.xlsx";

    public ExcelLogger() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Registration Log");

        Row header = sheet.createRow(rowCount++);
        header.createCell(0).setCellValue("Timestamp");
        header.createCell(1).setCellValue("Action Description");
    }

    public void log(String action) {
        Row row = sheet.createRow(rowCount++);
        row.createCell(0).setCellValue(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        row.createCell(1).setCellValue(action);
    }

    public void save() {
        try (FileOutputStream outputStream = new FileOutputStream(FILE_NAME)) {
            workbook.write(outputStream);
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
