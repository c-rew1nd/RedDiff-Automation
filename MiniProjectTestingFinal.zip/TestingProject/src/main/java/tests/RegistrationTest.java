package tests;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import config.DriverSetup;
import pages.LoginPage;
import pages.RegistrationPage;
import utils.DataProvider;
import utils.ExceptionHandler;

public class RegistrationTest {
    private WebDriver driver;
    private Properties testData;

    @BeforeClass
    public void setup() {
        try {
            // Load test data
            testData = DataProvider.getTestData(".\\src\\main\\resources\\testdata.properties");

            // Setup driver
            driver = DriverSetup.getDriver(testData.getProperty("browser"));
            driver.manage().window().maximize();

            // Open the webpage
            driver.get(testData.getProperty("url"));
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    @Test
    public void registrationTest() {
        try {
            // Perform test steps
            LoginPage loginPage = new LoginPage(driver);
            loginPage.clickCreateAccount();

            RegistrationPage registrationPage = new RegistrationPage(driver);
            registrationPage.enterName(testData.getProperty("name"));
            registrationPage.enterRediffMailId(testData.getProperty("rediffMailId"));
            registrationPage.checkAvailability();
            registrationPage.selectSuggestedName();
            registrationPage.enterPassword(testData.getProperty("password"));
            registrationPage.selectDateOfBirth(testData.getProperty("dobDay"), testData.getProperty("dobMonth"), testData.getProperty("dobYear"));
            registrationPage.printCountryOptions();
            registrationPage.selectCountry(testData.getProperty("country"));
            registrationPage.validateSelectedCountry(testData.getProperty("expectedCountry"));
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
