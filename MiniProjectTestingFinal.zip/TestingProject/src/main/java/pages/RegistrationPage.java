package pages;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import utils.ExcelLogger;
import utils.ExcelReader;

public class RegistrationPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private ExcelLogger logger;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        this.logger = new ExcelLogger();
    }

    public void fillFormFromExcel(String filePath) throws IOException {
        ExcelReader reader = new ExcelReader(filePath, "Sheet1");
        String name = reader.getCellData(1, 0);
        String email = reader.getCellData(1, 1);
        String password = reader.getCellData(1, 2);
        String day = ((int) (Double.parseDouble(reader.getCellData(1, 3)))) + "";
        String month = reader.getCellData(1, 4);
        String year = ((int) (Double.parseDouble(reader.getCellData(1, 5)))) + "";
        String country = reader.getCellData(1, 6);

        enterName(name);
        enterRediffMailId(email);
        checkAvailability();
        selectSuggestedName();
        enterPassword(password);
        selectDateOfBirth(day, month, year);
        selectCountry(country);
    }

    public void enterName(String name) {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[2]/input")).sendKeys(name);
        logger.log("Entered name: " + name);
    }

    public void enterRediffMailId(String id) {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[3]/div/input")).sendKeys(id);
        logger.log("Entered RediffMail ID: " + id);
    }

    public void checkAvailability() {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[4]/input")).click();
        logger.log("Checked availability");
    }

    public void selectSuggestedName() {
        WebElement suggestedName = driver.findElement(By.xpath("//*[@id=\"radio_login\"]"));
        suggestedName.click();
        logger.log("Selected suggested name");
    }

    public void enterPassword(String password) {
        driver.findElement(By.id("newpasswd")).sendKeys(password);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newpasswd1"))).sendKeys(password);
        logger.log("Entered and confirmed password");
    }

    public void selectDateOfBirth(String day, String month, String year) {
        Select selectDay = new Select(driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[1]")));
        selectDay.selectByVisibleText(day);

        Select selectMonth = new Select(driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[2]")));
        selectMonth.selectByVisibleText(month);

        Select selectYear = new Select(driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[3]")));
        selectYear.selectByVisibleText(year);

        logger.log("Selected DOB: " + day + " " + month + " " + year);
    }

    public void selectCountry(String country) {
        new Select(driver.findElement(By.id("country"))).selectByVisibleText(country);
        logger.log("Selected country: " + country);
    }

    public void logAllCountryOptions() {
        Select selectCountryList = new Select(driver.findElement(By.id("country")));
        List<WebElement> options = selectCountryList.getOptions();
        logger.log("Listing all available countries:");
        for (WebElement option : options) {
            logger.log("Country option: " + option.getText());
        }
        logger.log("Total number of countries: " + options.size());
    }

    public boolean validateSelectedCountry(String expectedCountry) {
        Select select = new Select(driver.findElement(By.id("country")));
        String actual = select.getFirstSelectedOption().getText();
        boolean isValid = actual.equals(expectedCountry);
        if (isValid) {
            logger.log("Country validation passed: " + actual);
        } else {
            logger.log("Country validation failed: expected " + expectedCountry + ", got " + actual);
        }
        return isValid;
    }

    public boolean validateSelectedCountryFromExcel(String filePath) throws IOException {
        ExcelReader reader = new ExcelReader(filePath, "Sheet1");
        String expectedCountry = reader.getCellData(1, 6);
        return validateSelectedCountry(expectedCountry);
    }

    public void saveLog() {
        logger.save();
    }
}
