package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.LoginPage;
import pages.RegistrationPage;
import config.DriverSetup;
import utils.ExceptionHandler;

public class RegistrationTest {
    private WebDriver driver;

    @Parameters("browser")
    @BeforeClass
    public void setup(@Optional("chrome") String browser) {
        try {
            driver = DriverSetup.getDriver(browser);
            driver.manage().window().maximize();
            driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    @Test(priority = 1)
    public void registrationTest() {
        try {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.clickCreateAccount();
            RegistrationPage registrationPage = new RegistrationPage(driver);
            String excelPath = "src/test/resources/registration_input.xlsx";
            registrationPage.fillFormFromExcel(excelPath);
            registrationPage.logAllCountryOptions();
            boolean isCountryValid = registrationPage.validateSelectedCountryFromExcel(excelPath);
            Assert.assertTrue(isCountryValid, "Selected country does not match expected country.");
            registrationPage.saveLog();
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }
    @Test (priority = 0)
    public void openBrower() {
    	Assert.assertEquals(driver.getTitle(), "Rediffmail - Free Email for Login with Secure Access");
    }
    
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
