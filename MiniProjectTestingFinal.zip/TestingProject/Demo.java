import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Demo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		WebDriverWait mywait = new WebDriverWait(driver,Duration.ofSeconds(15));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		driver.manage().window().maximize();
		
		WebElement formLink = mywait.until(ExpectedConditions.elementToBeClickable(By.linkText("Get a new Rediffmail ID")));
		formLink.click();
		
		WebElement nameEnter = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[2]/input"));
		nameEnter.sendKeys("kamal");
		
		WebElement idEnter = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[3]/div/input"));
		idEnter.sendKeys("kamal1234");
		
		WebElement checkAvailibilityBtn = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[4]/input"));
		checkAvailibilityBtn.click();
		
		WebElement suggestedName = driver.findElement(By.xpath("//*[@id=\"radio_login\"]"));
		suggestedName.click();
		
		WebElement enterPass = driver.findElement(By.id("newpasswd"));
		enterPass.sendKeys("Kamal@1234");
		
		WebElement reEnterPass = mywait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newpasswd1")));
		reEnterPass.sendKeys("Kamal@1234");
		
		WebElement dobDay = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[1]"));
		Select selectDay = new Select(dobDay);
		selectDay.selectByVisibleText("20");
		
		WebElement dobMonth = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[2]"));
		Select selectMonth = new Select(dobMonth);
		selectMonth.selectByVisibleText("JUN");
		
		WebElement dobYear = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div/div[8]/select[3]"));
		Select selectYear = new Select(dobYear);
		selectYear.selectByVisibleText("2000");
		
		WebElement countryDropDownOptions = driver.findElement(By.id("country"));
		Select selectCountryList = new Select(countryDropDownOptions);
		List<WebElement> options = selectCountryList.getOptions();
		selectCountryList.selectByVisibleText("Tuvalu");
		
		for (WebElement option : options){
			System.out.println(option.getText());
		}
		
//		WebElement selectedCountry = driver.findElement(By.id("country"));
//		System.out.println(selectedCountry.getText());
		
		

		
		
		driver.quit();
		
		
		
		
		

	}